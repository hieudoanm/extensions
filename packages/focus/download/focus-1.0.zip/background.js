/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/*!***************************!*\
  !*** ./src/background.ts ***!
  \***************************/

const BLOCKED_SITES = [
    'facebook.com',
    'twitter.com',
    'instagram.com',
    'youtube.com',
    'tiktok.com',
];
/** Helper: Check if URL is blocked */
function isBlocked(url) {
    try {
        const hostname = new URL(url).hostname;
        console.log('[Focus] Checking hostname:', hostname);
        const matched = BLOCKED_SITES.some((site) => hostname.includes(site));
        console.log('[Focus] Matched blocked site?', matched);
        return matched;
    }
    catch (err) {
        console.error('[Focus] Error parsing URL:', url, err);
        return false;
    }
}
/** Listener: Intercept and redirect blocked sites */
console.log('[Focus] Background script loaded');
browser.webRequest.onBeforeRequest.addListener((details) => {
    console.log('[Focus] Intercepted request:', details.url);
    if (isBlocked(details.url)) {
        try {
            const blockedPage = browser.runtime.getURL('blocked.html');
            console.log('[Focus] Blocking and redirecting tab', details.tabId, 'to', blockedPage); // Cancel the request
            browser.tabs.update(details.tabId, { url: blockedPage });
            return { cancel: true };
        }
        catch (error) {
            console.error('[Focus] Redirect error:', error);
        }
    }
    else {
        console.log('[Focus] URL not blocked:', details.url);
    }
}, { urls: ['<all_urls>'], types: ['main_frame'] }, ['blocking']);

/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmFja2dyb3VuZC5qcyIsIm1hcHBpbmdzIjoiOzs7OztBQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtR0FBbUc7QUFDbkcsaURBQWlELGtCQUFrQjtBQUNuRSxxQkFBcUI7QUFDckI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUMsSUFBSSw2Q0FBNkMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9AZm9jdXMvZXh0ZW5zaW9uLy4vc3JjL2JhY2tncm91bmQudHMiXSwic291cmNlc0NvbnRlbnQiOlsiXCJ1c2Ugc3RyaWN0XCI7XG5jb25zdCBCTE9DS0VEX1NJVEVTID0gW1xuICAgICdmYWNlYm9vay5jb20nLFxuICAgICd0d2l0dGVyLmNvbScsXG4gICAgJ2luc3RhZ3JhbS5jb20nLFxuICAgICd5b3V0dWJlLmNvbScsXG4gICAgJ3Rpa3Rvay5jb20nLFxuXTtcbi8qKiBIZWxwZXI6IENoZWNrIGlmIFVSTCBpcyBibG9ja2VkICovXG5mdW5jdGlvbiBpc0Jsb2NrZWQodXJsKSB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgaG9zdG5hbWUgPSBuZXcgVVJMKHVybCkuaG9zdG5hbWU7XG4gICAgICAgIGNvbnNvbGUubG9nKCdbRm9jdXNdIENoZWNraW5nIGhvc3RuYW1lOicsIGhvc3RuYW1lKTtcbiAgICAgICAgY29uc3QgbWF0Y2hlZCA9IEJMT0NLRURfU0lURVMuc29tZSgoc2l0ZSkgPT4gaG9zdG5hbWUuaW5jbHVkZXMoc2l0ZSkpO1xuICAgICAgICBjb25zb2xlLmxvZygnW0ZvY3VzXSBNYXRjaGVkIGJsb2NrZWQgc2l0ZT8nLCBtYXRjaGVkKTtcbiAgICAgICAgcmV0dXJuIG1hdGNoZWQ7XG4gICAgfVxuICAgIGNhdGNoIChlcnIpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcignW0ZvY3VzXSBFcnJvciBwYXJzaW5nIFVSTDonLCB1cmwsIGVycik7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG59XG4vKiogTGlzdGVuZXI6IEludGVyY2VwdCBhbmQgcmVkaXJlY3QgYmxvY2tlZCBzaXRlcyAqL1xuY29uc29sZS5sb2coJ1tGb2N1c10gQmFja2dyb3VuZCBzY3JpcHQgbG9hZGVkJyk7XG5icm93c2VyLndlYlJlcXVlc3Qub25CZWZvcmVSZXF1ZXN0LmFkZExpc3RlbmVyKChkZXRhaWxzKSA9PiB7XG4gICAgY29uc29sZS5sb2coJ1tGb2N1c10gSW50ZXJjZXB0ZWQgcmVxdWVzdDonLCBkZXRhaWxzLnVybCk7XG4gICAgaWYgKGlzQmxvY2tlZChkZXRhaWxzLnVybCkpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IGJsb2NrZWRQYWdlID0gYnJvd3Nlci5ydW50aW1lLmdldFVSTCgnYmxvY2tlZC5odG1sJyk7XG4gICAgICAgICAgICBjb25zb2xlLmxvZygnW0ZvY3VzXSBCbG9ja2luZyBhbmQgcmVkaXJlY3RpbmcgdGFiJywgZGV0YWlscy50YWJJZCwgJ3RvJywgYmxvY2tlZFBhZ2UpOyAvLyBDYW5jZWwgdGhlIHJlcXVlc3RcbiAgICAgICAgICAgIGJyb3dzZXIudGFicy51cGRhdGUoZGV0YWlscy50YWJJZCwgeyB1cmw6IGJsb2NrZWRQYWdlIH0pO1xuICAgICAgICAgICAgcmV0dXJuIHsgY2FuY2VsOiB0cnVlIH07XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKCdbRm9jdXNdIFJlZGlyZWN0IGVycm9yOicsIGVycm9yKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgY29uc29sZS5sb2coJ1tGb2N1c10gVVJMIG5vdCBibG9ja2VkOicsIGRldGFpbHMudXJsKTtcbiAgICB9XG59LCB7IHVybHM6IFsnPGFsbF91cmxzPiddLCB0eXBlczogWydtYWluX2ZyYW1lJ10gfSwgWydibG9ja2luZyddKTtcbiJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==